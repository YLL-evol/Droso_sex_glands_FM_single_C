# FlyCellAtlas Sexual Glands Dimorphism Single Cell analysis — SMART‑seq2
## Male reproductive glands vs Female ovary (Drosophila)
This notebook performs:
- descriptive statistics (beginning)
- QC for SMART-seq2
- normalization
- integration male vs female
- clustering
- cell type annotation using marker genes
- differential abundance
- differential expression
- sexual conflict gene enrichment
- GO enrichment / pathway enrichment
- trajectory inference
- descriptive statistics (final)

All markdown sections dynamically display computed values.

## 0. Environment



```python
# In PC, anaconda, click the current environment, click play button, open in terminal, and pip install
conda create -n Droso_sex_glands_FM_single_C python=3.10 -y
conda activate Droso_sex_glands_FM_single_C

pip install scanpy scvelo seaborn matplotlib pandas numpy
pip install harmonypy anndata leidenalg bbknn   # Microsoft Visual C++ 14.0 or greater is required. Get it with "Microsoft C++ Build Tools": https://visualstudio.microsoft.com/visual-cpp-build-tools/
pip install gseapy goatools
```


      Cell In[1], line 1
        conda create -n fly_sex_sc python=3.10 -y
              ^
    SyntaxError: invalid syntax
    


## 1. Imports


```python
import scanpy as sc
import scvelo as scv
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

from IPython.display import Markdown, display
import gseapy as gp
```

## 2. Load SMART‑seq2 H5AD


```python
PATH_TO = "C:/Users/hi/Documents/YLL_evol/Droso_sex_glands_FM_single_C"
male_path = "C:/Users/hi/Documents/YLL_evol/Droso_sex_glands_FM_single_C/male_reproductive_glands.h5ad"
female_path = "C:/Users/hi/Documents/YLL_evol/Droso_sex_glands_FM_single_C/ovary.h5ad"

male = sc.read(male_path)
female = sc.read(female_path)

male.obs["sex"] = "male"
female.obs["sex"] = "female"

adata = male.concatenate(female)
```

## 3. Descriptive statistics — RAW DATA


```python
n_genes = adata.n_vars

male_cells = (adata.obs.sex == "male").sum()
female_cells = (adata.obs.sex == "female").sum()
n_cells = male_cells 

counts_per_cell = np.mean(adata.X.sum(axis=1))

display(Markdown(f"""
## Raw dataset statistics

Total cells: **{n_cells}**  
Total genes: **{n_genes}**  
Male cells: **{male_cells}**  
Female cells: **{female_cells}**  
Mean counts per cell: **{counts_per_cell:.2f}**
"""))
```



## Raw dataset statistics

Total cells: **238**  
Total genes: **16311**  
Male cells: **238**  
Female cells: **1011**  
Mean counts per cell: **10578.29**



## 4. QC metrics SMART‑seq2


```python
adata.var['mt'] = adata.var_names.str.startswith('mt:')

sc.pp.calculate_qc_metrics(
    adata,
    qc_vars=['mt'],
    inplace=True
)
```

## 5. QC plots


```python
sc.pl.violin(
    adata,
    ['n_genes_by_counts','total_counts','pct_counts_mt'],
    groupby='sex'
)
```


    
![png](output_12_0.png)
    


## 6. Filtering SMART‑seq2

For SMART-seq2, thresholds must be higher than 10x.

SMART-seq2 typical values

SMART-seq2:

genes per cell: 1500–8000
counts per cell: 100k–1M
mito %: <10–20%

References:

Picelli et al. 2014 SMART-seq2 (Nature Methods)
Hagemann-Jensen et al. 2020 Smart-seq3 (Nature Biotechnology)
Lun et al. 2016 single-cell QC (Genome Biology)

Data-driven threshold, choose cutoffs visually.


```python
sc.pl.violin(
    adata,
    ["n_genes_by_counts","total_counts","pct_counts_mt"]
)
```


    
![png](output_15_0.png)
    



```python
adata = adata[adata.obs.n_genes_by_counts > 500] #low-quality cells (left tail), choose cutoff just before density rises
adata = adata[adata.obs.n_genes_by_counts < 6000] #SMART-seq2 doublets have too many genes
adata = adata[adata.obs.pct_counts_mt < 15] # mitochondrial cutoff dead cells
```

## 7. Normalize


```python
sc.pp.normalize_total(adata, target_sum=1e6)
sc.pp.log1p(adata)
```

## 8. Highly variable genes


```python
sc.pp.highly_variable_genes(
    adata,
    flavor="seurat",
    n_top_genes=3000
)
```

## 9. PCA + UMAP


```python
sc.tl.pca(adata)
sc.pp.neighbors(adata)
sc.tl.umap(adata)
sc.tl.leiden(adata, resolution=0.5)

sc.pl.pca_variance_ratio(
    adata,
    log=True,
    n_pcs=50
)

var = adata.uns["pca"]["variance_ratio"]

plt.figure(figsize=(6,4))
plt.scatter(
    range(1,len(var)+1),
    var
)

plt.xlabel("Principal component")
plt.ylabel("Variance explained")
plt.title("PCA variance ratio")

plt.plot(np.cumsum(var))
plt.xlabel("PC")
plt.ylabel("Cumulative variance")
```


    
![png](output_22_0.png)
    





    Text(0, 0.5, 'Cumulative variance')




    
![png](output_22_2.png)
    


PCA colored by sex:


```python
sc.pl.pca(
    adata,
    color="sex",
    size=40
)
```


    
![png](output_24_0.png)
    


## 10. Cell type annotation using marker genes
User can modify marker genes list. 

These are classic Drosophila reproductive markers

**Accessory gland**
Acp36DE — seminal protein
Acp26Aa — accessory gland secretion
Acp70A (sex peptide)

References:

Chapman et al. 2003
Nature — sex peptide sexual conflict

Wolfner 2002
Annual Review — accessory gland proteins

**Germline**
vasa — germline helicase
nanos — germline stem cell

References:

Lasko & Ashburner 1988
Nature — vasa

Wang & Lehmann 1991
Cell — nanos

**Follicle cells**
Fas3 — follicle epithelium
ct — ovarian somatic cells

Reference:

Spradling 1993
Development


```python
marker_genes = {
    "Accessory_gland": ["Acp36DE","Acp26Aa"], #,"Acp70A"
    "Testis_somatic": ["tj","eya"],
   # "Germline": ["vasa","nanos"],
    "Follicle_cells": ["Fas3","ct"],
    "Nurse_cells": ["otu","orb"]
}

# KeyError: "Could not find keys [np.str_('Acp70A'), np.str_('nanos'), np.str_('vasa')] in columns of `adata.obs` or in adata.var_names."
# --> delete unfind keys

sc.pl.dotplot(
    adata,
    marker_genes,
    groupby="leiden"
)
```


    
![png](output_26_0.png)
    


Assign labels


```python
cluster_annotation = {
    "0":"Accessory_gland",
    "1":"Germline",
    "2":"Follicle_cells"
}

adata.obs["cell_type"] = adata.obs.leiden.map(cluster_annotation)
```

Plot annotated


```python
sc.pl.umap(
    adata,
    color=["cell_type","sex"]
)
```


    
![png](output_30_0.png)
    


## 11. Sexual dimorphism cell proportion


```python
prop = pd.crosstab(
    adata.obs['cell_type'],
    adata.obs['sex'],
    normalize='columns'
)

prop.plot(kind='bar')
plt.title("Sexual dimorphism by cell type")
```




    Text(0.5, 1.0, 'Sexual dimorphism by cell type')




    
![png](output_32_1.png)
    



```python
prop = pd.crosstab(
    adata.obs["leiden"],
    adata.obs["sex"],
    normalize="columns"
)

prop.plot(
    kind="bar",
    figsize=(8,4)
)

plt.title("Cell proportion male vs female")
plt.ylabel("Fraction")
plt.xlabel("Cluster")
plt.legend(title="Sex")

```




    <matplotlib.legend.Legend at 0x214bfe67cd0>




    
![png](output_33_1.png)
    


## 12. Differential expression


```python
sc.tl.rank_genes_groups(
    adata,
    groupby='sex',
    method='wilcoxon'
)

sc.pl.rank_genes_groups_heatmap(
    adata,
    n_genes=10,
    groupby="sex"
)

sc.pl.rank_genes_groups_dotplot(
    adata,
    n_genes=10
)

deg = sc.get.rank_genes_groups_df(adata, group="male")

plt.scatter(
deg.logfoldchanges,
-deg.pvals_adj.apply(np.log10)
)

deg = sc.get.rank_genes_groups_df(adata, group="female")

plt.scatter(
deg.logfoldchanges,
-deg.pvals_adj.apply(np.log10)
)
```


    
![png](output_35_0.png)
    


    WARNING: Dendrogram not added. Dendrogram is added only when the number of categories to plot > 2
    


    
![png](output_35_2.png)
    





    <matplotlib.collections.PathCollection at 0x214c7275bd0>




    
![png](output_35_4.png)
    


## 13. Sexual conflict gene enrichment 
User defines sexual conflict gene list. 

Why these genes:

Sexual conflict genes:

**sex peptide**

male manipulates female reproduction

Chapman et al. 2003 Nature

**Acps**

male seminal proteins

sexual conflict evolution

Wolfner 1997

**doublesex**

sexual dimorphism regulator

Burtis & Baker 1989 Cell

**fruitless**

male mating behavior

Villella 1997 Cell

**ovo**

female germline

sexual antagonism

Mevel-Ninio 1996


```python
sexual_conflict_genes = [
    "Acp36DE",
    "Acp62F",
    "sex_peptide",
    "fruitless",
    "doublesex",
    "ovo"
]

# WARNING: genes are not in var_names and ignored: Index(['sex_peptide', 'fruitless', 'doublesex'], dtype='object')

sc.tl.score_genes(
    adata,
    sexual_conflict_genes,
    score_name="sexual_conflict_score"
)

sc.pl.umap(
    adata,
    color="sexual_conflict_score"
)


```

    WARNING: genes are not in var_names and ignored: Index(['sex_peptide', 'fruitless', 'doublesex'], dtype='object')
    


    
![png](output_37_1.png)
    


Statistics


```python
male_score = adata.obs.loc[
    adata.obs.sex=="male",
    "sexual_conflict_score"
].mean()

female_score = adata.obs.loc[
    adata.obs.sex=="female",
    "sexual_conflict_score"
].mean()

display(Markdown(f"""
## Sexual conflict enrichment

Mean male score: **{male_score:.3f}**  
Mean female score: **{female_score:.3f}**
"""))
```



## Sexual conflict enrichment

Mean male score: **3.502**  
Mean female score: **-1.177**



## 14. GO enrichment
Extract top genes


```python
deg = sc.get.rank_genes_groups_df(adata, group="male")
top_genes = deg.names.head(200).tolist()
```


```python
# check what library available, 
# usually it needs to download the file and charge from local: https://maayanlab.cloud/Enrichr/#libraries  look for GO_Biological_Process_2025, KEGG_2026, KEGG_2021_human, change file type to .gmt
# gp.get_library_name()

# print(top_genes[0:20]) 
# no need to concert gene name
# check gene name readable for GO, if not download on https://flybase.org/downloads/bulkdata, fbgn_annotation_ID_fb_2026_01.tsv, gene_association.fb
```

Run GO


```python
go = gp.enrichr(
    gene_list=top_genes,
    organism='fly',
    gene_sets="GO_Biological_Process_2025.gmt",
    outdir=None
)
```

plot


```python
gp.barplot(
    go.results,
    title="GO enrichment male bias"
)
```




    <Axes: title={'center': 'GO enrichment male bias'}, xlabel='$- \\log_{10}$ (Adjusted P-value)'>




    
![png](output_46_1.png)
    


## 15. Pathway enrichment


```python
kegg = gp.enrichr(
    gene_list=top_genes,
    organism='fly',
    gene_sets="KEGG_2021_human.gmt",
    outdir=None
)
# NB: pecies name in minuscule.

gp.barplot(kegg.results)
```




    <Axes: xlabel='$- \\log_{10}$ (Adjusted P-value)'>




    
![png](output_48_1.png)
    


## 16. Pseudotime


```python
sc.pp.neighbors(adata)

adata.uns["iroot"] = np.flatnonzero(
adata.obs.leiden == "0"
)[0]

sc.tl.dpt(adata)

sc.pl.umap(
adata,
color=["dpt_pseudotime","sex"]
)
```

    WARNING: Trying to run `tl.dpt` without prior call of `tl.diffmap`. Falling back to `tl.diffmap` with default parameters.
    


    
![png](output_50_1.png)
    



```python
sc.pl.violin(
    adata,
    "dpt_pseudotime",
    groupby="leiden"
)

sc.pl.violin(
    adata,
    "dpt_pseudotime",
    groupby="sex"
)

```


    
![png](output_51_0.png)
    



    
![png](output_51_1.png)
    


**Female ovary is more differenciated?**
**Male develops earlier?**


```python
sc.pl.umap(
    adata,
    color=["cell_type","dpt_pseudotime"]
)
```


    
![png](output_53_0.png)
    


Interpret:

gradient inside cluster → differentiation
gradient across clusters → lineage

## 17. Final descriptive statistics


```python
n_clusters = adata.obs["leiden"].nunique()

cluster_counts = pd.crosstab(
    adata.obs["leiden"],
    adata.obs["sex"]
)

display(cluster_counts)

cluster_counts.plot(
    kind="bar",
    figsize=(8,4)
)

plt.title("Cluster counts male vs female")

ratio = cluster_counts.div(
    cluster_counts.sum(axis=0),
    axis=1
)

ratio.plot(kind="bar")

sc.pl.violin(
    adata,
    "dpt_pseudotime",
    groupby="sex"
)

display(Markdown(f"""
# Final summary

Clusters: {n_clusters}

Total cells: {adata.n_obs}

Mean pseudotime male:
{adata.obs.loc[adata.obs.sex=="male","dpt_pseudotime"].mean():.3f}

Mean pseudotime female:
{adata.obs.loc[adata.obs.sex=="female","dpt_pseudotime"].mean():.3f}
"""))

```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>sex</th>
      <th>female</th>
      <th>male</th>
    </tr>
    <tr>
      <th>leiden</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>305</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>191</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>171</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>115</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>109</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0</td>
      <td>98</td>
    </tr>
    <tr>
      <th>6</th>
      <td>88</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>



    
![png](output_56_1.png)
    



    
![png](output_56_2.png)
    



    
![png](output_56_3.png)
    




# Final summary

Clusters: 7

Total cells: 1077

Mean pseudotime male:
0.842

Mean pseudotime female:
0.050


